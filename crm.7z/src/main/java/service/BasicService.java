package service;

public interface BasicService {

}
