package service;

import java.util.List;

import entity.Role;

public interface RoleService {

	public List<Role> getAll(String where);
}
