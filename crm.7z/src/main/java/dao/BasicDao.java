package dao;

public class BasicDao {

	
}
