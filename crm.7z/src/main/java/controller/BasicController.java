package controller;

public class BasicController {

}
